package com.example.internettest

import android.os.Bundle
import android.util.Log
import android.view.View
import android.widget.Button
import androidx.appcompat.app.AppCompatActivity
import okhttp3.*
import java.io.IOException
import java.net.HttpURLConnection
import java.net.URL
import kotlin.concurrent.thread


class MainActivity : AppCompatActivity() {

    companion object {
        private const val FLICKR_URL =
            "https://api.flickr.com/services/rest/?method=flickr.photos.search&api_key=ff49fcd4d4a08aa6aafb6ea3de826464&tags=cat&format=json&nojsoncallback=1"
    }

    private val viaUrlConnectionClickListener = View.OnClickListener {
        thread {
            val connection = URL(FLICKR_URL).openConnection() as HttpURLConnection
            val data = connection.inputStream.use {
                it.bufferedReader().readText()
            }
            Log.d("Flickr cats", data)
        }
    }

    private val viaOkHttpClickListener = View.OnClickListener {
        thread {
            val request: Request = Request.Builder()
                .url(FLICKR_URL)
                .build()

            val client = OkHttpClient()
            val call = client.newCall(request)
            call.enqueue(object : Callback {
                override fun onFailure(call: Call, e: IOException) {
                    Log.e("Flickr OkCats", "Loading failure: ${e.message}")
                }

                override fun onResponse(call: Call, response: Response) {
                    Log.i("Flickr OkCats", response.body?.string() ?: "No data")
                }
            })
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        findViewById<Button>(R.id.btnHTTP).setOnClickListener(viaUrlConnectionClickListener)
        findViewById<Button>(R.id.btnOkHTTP).setOnClickListener(viaOkHttpClickListener)
    }

}