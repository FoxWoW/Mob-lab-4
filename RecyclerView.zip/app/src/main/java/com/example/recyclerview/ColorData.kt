package com.example.recyclerview

class ColorData(
    val colorName: String,
    val colorHex: Int,
)