package com.example.recyclerview

import android.graphics.Color
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.Toast
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView

class MainActivity : AppCompatActivity(), Adapter.CellClickListener {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        val colors = createColors()
        val adapter = Adapter(this, colors, this)
        with(findViewById<RecyclerView>(R.id.rView)) {
            this.adapter = adapter
            this.layoutManager = LinearLayoutManager(this@MainActivity)
        }
    }

    private fun createColors(): ArrayList<ColorData> {
        return arrayListOf(
            ColorData("WHITE", Color.WHITE),
            ColorData("BLACK", Color.BLACK),
            ColorData("BLUE", Color.BLUE),
            ColorData("GREEN", Color.GREEN),
            ColorData("RED", Color.RED),
            ColorData("YELLOW", Color.YELLOW),
            ColorData("MAGENTA", Color.MAGENTA),
        )
    }

    override fun onCellClickListener(colorData: ColorData) {
        Toast.makeText(this, "IT'S ${colorData.colorName.uppercase()}", Toast.LENGTH_SHORT).show()
    }
}