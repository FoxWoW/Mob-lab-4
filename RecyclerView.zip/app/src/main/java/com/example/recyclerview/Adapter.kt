package com.example.recyclerview

import android.content.Context
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView

class Adapter(
    private val context: Context,
    private val list: ArrayList<ColorData>,
    private val onCellClickListener: CellClickListener,
) : RecyclerView.Adapter<Adapter.ViewHolder>() {

    interface CellClickListener {
        fun onCellClickListener(colorData: ColorData)
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ViewHolder {
        return ViewHolder(
            LayoutInflater.from(context).inflate(R.layout.rview_item, parent, false)
        )
    }

    override fun onBindViewHolder(holder: ViewHolder, position: Int) {
        holder.bind(list[position])
    }

    override fun getItemCount(): Int = list.size

    inner class ViewHolder(itemView: View) : RecyclerView.ViewHolder(itemView) {
        private val tvName = itemView.findViewById<TextView>(R.id.color_name)
        private val vBg = itemView.findViewById<View>(R.id.color_bg)

        init {
            // подписываем при создании VH и используем данные на момент клика,
            // чтобы не пересоздавать слушатель всякий раз при onBind
            itemView.setOnClickListener {
                val data = list[adapterPosition]
                onCellClickListener.onCellClickListener(data)
            }
        }

        fun bind(colorData: ColorData) {
            tvName.text = colorData.colorName.uppercase()
            vBg.setBackgroundColor(colorData.colorHex)
        }
    }

}